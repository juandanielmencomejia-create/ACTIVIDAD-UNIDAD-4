# Hoja de vida – Actividad Unidad 4

Migración del sitio de hoja de vida (HTML + Bootstrap + jQuery de la Unidad 2) a **React (Vite)**, conservando el diseño original. Se agrega un panel administrativo (`/admin`) con CRUD de experiencias profesionales que consume la API de la Unidad 3.

## Requisitos
- Node.js 18 o superior
- La API de la Unidad 3 (`hoja-vida-api`) en ejecución: `npm start` (por defecto `http://localhost:3000`)

## Ejecutar
```bash
npm install
cp .env.example .env     # en Windows: copy .env.example .env
npm run dev              # http://localhost:5173
```
Si la API corre en otra dirección, cambia `VITE_API_URL` en `.env`.

## Rutas
| Ruta | Contenido |
|------|-----------|
| `/` | Inicio |
| `/formacion` | Formación académica |
| `/experiencia` | Experiencia laboral (leída desde la API) |
| `/habilidades` | Habilidades técnicas y blandas |
| `/contacto` | Contacto y formulario con validación |
| `/admin` | CRUD de experiencias |

## CRUD (`src/api/experiencias.js`)
| Acción | Petición |
|--------|----------|
| Listar / buscar | `GET /api/experiencias?q=` |
| Crear | `POST /api/experiencias` |
| Editar | `PUT /api/experiencias/:id` |
| Eliminar | `DELETE /api/experiencias/:id` |

## Qué cambió respecto al sitio original
- Cinco archivos `.html` → un componente por página (`src/pages`) con React Router.
- `main.js` con jQuery → React: menú móvil (`Layout`), animación de aparición (`Reveal`) y validación del formulario (`Contacto`).
- La experiencia ya no está escrita a mano: viene de la base de datos vía API.
- `style.css` se conserva igual; solo se agregaron estilos para el panel al final del archivo.

## Estructura
```
src/
  api/experiencias.js     llamadas a la API
  components/             Layout, Reveal, formulario, confirmación, avisos
  pages/                  Inicio, Formacion, Experiencia, Habilidades, Contacto, Admin
  style.css
public/images/juan.jpeg
```

## Publicación
`npm run build` genera `dist/`. En hosting estático, redirige todas las rutas a `index.html` para que `/admin` y las demás funcionen al recargar.
