import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import Inicio from './pages/Inicio.jsx';
import Formacion from './pages/Formacion.jsx';
import Experiencia from './pages/Experiencia.jsx';
import Habilidades from './pages/Habilidades.jsx';
import Contacto from './pages/Contacto.jsx';
import Admin from './pages/Admin.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Inicio />} />
        <Route path="/formacion" element={<Formacion />} />
        <Route path="/experiencia" element={<Experiencia />} />
        <Route path="/habilidades" element={<Habilidades />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<main><p className="eyebrow">404</p><h2>Página no encontrada</h2></main>} />
      </Route>
    </Routes>
  );
}
