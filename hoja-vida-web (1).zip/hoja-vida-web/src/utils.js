const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

export function formatearFecha(iso) {
  if (!iso) return '';
  const [y, m] = iso.slice(0, 10).split('-');
  return `${MESES[Number(m) - 1]} ${y}`;
}

export function periodo(exp) {
  const ini = formatearFecha(exp.fechaInicio);
  const fin = exp.trabajoActual ? 'Actualidad' : formatearFecha(exp.fechaFin);
  if (ini && fin) return `${ini} – ${fin}`;
  return ini || fin || '';
}
