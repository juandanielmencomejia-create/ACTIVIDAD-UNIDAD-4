// Capa de servicios: todas las llamadas a la API de la Unidad 3 están aquí.
const BASE = (import.meta.env.VITE_API_URL || 'http://localhost:3000').replace(/\/$/, '');
const URL = `${BASE}/api/experiencias`;

async function request(url, options = {}) {
  let res;
  try {
    res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch {
    throw new Error('No se pudo conectar con la API. Verifica que el servidor esté activo.');
  }
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detalle = json.errores?.length ? `: ${json.errores.join('. ')}` : '';
    throw new Error((json.mensaje || `Error ${res.status}`) + detalle);
  }
  return json;
}

export async function listarExperiencias(q = '') {
  const params = new URLSearchParams({ limite: '100' });
  if (q.trim()) params.set('q', q.trim());
  const json = await request(`${URL}?${params}`);
  return json.data;
}

export async function crearExperiencia(datos) {
  return (await request(URL, { method: 'POST', body: JSON.stringify(datos) })).data;
}

export async function actualizarExperiencia(id, datos) {
  return (await request(`${URL}/${id}`, { method: 'PUT', body: JSON.stringify(datos) })).data;
}

export async function eliminarExperiencia(id) {
  return (await request(`${URL}/${id}`, { method: 'DELETE' })).data;
}
