import Reveal from '../components/Reveal.jsx';

const ESTUDIOS = [
  {
    titulo: 'Ingeniería de Software',
    periodo: '2025 — en curso',
    sub: 'IV semestre',
    puntos: ['Formación en desarrollo de software, bases de datos y análisis de sistemas.'],
  },
  {
    titulo: 'Técnico en Sistemas Informáticos',
    periodo: 'Ene 2025 — Jul 2025',
    puntos: ['Formación técnica orientada a soporte, mantenimiento y fundamentos de sistemas informáticos.'],
  },
  {
    titulo: 'Educación media — Liceo Joaquín Fernando Vélez',
    periodo: 'Finalizado 2024',
    puntos: ['Bachillerato académico.'],
  },
];

export default function Formacion() {
  return (
    <main>
      <p className="eyebrow">hoja-de-vida / formación</p>
      <h2 style={{ marginBottom: '0.4rem' }}><span className="idx">02</span> Formación académica</h2>
      <p style={{ marginBottom: '2rem' }}>Estudios técnicos, universitarios y de educación media.</p>

      <div className="timeline">
        {ESTUDIOS.map((e) => (
          <Reveal key={e.titulo} className="card">
            <div className="card-head">
              <span className="card-title">{e.titulo}</span>
              <span className="card-period">{e.periodo}</span>
            </div>
            {e.sub && <p className="card-sub">{e.sub}</p>}
            <ul>{e.puntos.map((p) => <li key={p}>{p}</li>)}</ul>
          </Reveal>
        ))}
      </div>
    </main>
  );
}
