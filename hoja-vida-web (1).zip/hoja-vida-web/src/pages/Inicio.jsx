import Reveal from '../components/Reveal.jsx';

export default function Inicio() {
  return (
    <main>
      <Reveal as="section" className="hero row gy-4 align-items-center">
        <div className="col-12 col-md-8 order-2 order-md-1">
          <p className="eyebrow">hoja-de-vida / perfil</p>
          <h1>Juan Daniel<br />Menco Mejía</h1>
          <p className="hero-role">Estudiante de Ingeniería de Software · IV semestre</p>
          <p className="hero-desc">
            Técnico en Sistemas Informáticos y estudiante de Ingeniería de Software,
            con interés en bases de datos y soporte técnico. Me caracterizo por el
            trabajo en equipo, el liderazgo y mantener la calma en situaciones de
            alta presión.
          </p>
          <div className="tag-row">
            <span className="tag"><span className="glyph">📍</span> Magangué Bolívar</span>
            <span className="tag"><span className="glyph">🎓</span> Ing. de Software</span>
            <span className="tag"><span className="glyph">💻</span> Técnico en Sistemas</span>
          </div>
        </div>
        <div className="col-12 col-md-4 order-1 order-md-2 d-flex justify-content-center justify-content-md-end">
          <div className="hero-photo-wrap">
            <img src="/images/juan.jpeg" alt="Foto de Juan Daniel Menco Mejía" />
          </div>
        </div>
      </Reveal>

      <section>
        <h2><span className="idx">01</span> Sobre mí</h2>
        <Reveal className="card">
          <p>
            Soy graduado como Técnico en Sistemas Informáticos y actualmente curso
            cuarto semestre de Ingeniería de Software. He tenido experiencia
            laboral en distintas áreas —domicilios, logística en bodega y soporte
            técnico en el sector salud— lo que me ha dado disciplina, capacidad de
            adaptación y facilidad para trabajar bajo presión. Busco seguir
            creciendo profesionalmente en el mundo del desarrollo y la gestión de
            bases de datos.
          </p>
        </Reveal>
      </section>
    </main>
  );
}
