import { useCallback, useEffect, useState } from 'react';
import {
  listarExperiencias, crearExperiencia, actualizarExperiencia, eliminarExperiencia,
} from '../api/experiencias.js';
import ExperienciaForm from '../components/ExperienciaForm.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import Toast from '../components/Toast.jsx';
import { periodo } from '../utils.js';

export default function Admin() {
  const [items, setItems] = useState([]);
  const [busqueda, setBusqueda] = useState('');
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [formulario, setFormulario] = useState(null); // null | { experiencia } (experiencia null = nueva)
  const [guardando, setGuardando] = useState(false);
  const [porEliminar, setPorEliminar] = useState(null);
  const [eliminando, setEliminando] = useState(false);
  const [toast, setToast] = useState(null);

  const cargar = useCallback(async (q = '') => {
    setCargando(true);
    setError('');
    try {
      setItems(await listarExperiencias(q));
    } catch (err) {
      setError(err.message);
    } finally {
      setCargando(false);
    }
  }, []);

  // Búsqueda con pequeña espera para no llamar a la API en cada tecla.
  useEffect(() => {
    const t = setTimeout(() => cargar(busqueda), 300);
    return () => clearTimeout(t);
  }, [busqueda, cargar]);

  const guardar = async (datos) => {
    setGuardando(true);
    try {
      const id = formulario.experiencia?._id;
      if (id) await actualizarExperiencia(id, datos);
      else await crearExperiencia(datos);
      setFormulario(null);
      setToast({ tipo: 'ok', texto: id ? 'Experiencia actualizada' : 'Experiencia creada' });
      await cargar(busqueda);
    } catch (err) {
      setToast({ tipo: 'error', texto: err.message });
    } finally {
      setGuardando(false);
    }
  };

  const eliminar = async () => {
    setEliminando(true);
    try {
      await eliminarExperiencia(porEliminar._id);
      setPorEliminar(null);
      setToast({ tipo: 'ok', texto: 'Experiencia eliminada' });
      await cargar(busqueda);
    } catch (err) {
      setToast({ tipo: 'error', texto: err.message });
    } finally {
      setEliminando(false);
    }
  };

  return (
    <main>
      <p className="eyebrow">hoja-de-vida / admin</p>
      <div className="admin-head">
        <div>
          <h2 style={{ marginBottom: '0.4rem' }}><span className="idx">07</span> Administrar experiencias</h2>
          <p>Crea, edita o elimina las experiencias que se muestran en el sitio.</p>
        </div>
        <button className="btn-submit" onClick={() => setFormulario({ experiencia: null })}>+ Nueva</button>
      </div>

      <div className="form-group">
        <input
          className="form-control"
          type="search"
          placeholder="Buscar por cargo, empresa o descripción…"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />
      </div>

      {error && <div className="api-error">{error}</div>}
      {cargando && <p>Cargando…</p>}
      {!cargando && !error && items.length === 0 && <p>No hay experiencias para mostrar.</p>}

      {items.map((exp) => (
        <div key={exp._id} className="admin-item">
          <div>
            <div className="admin-item__title">{exp.cargo}</div>
            <div className="admin-item__meta">
              {[exp.empresa, periodo(exp)].filter(Boolean).join(' · ')}
            </div>
          </div>
          <div className="admin-actions">
            <button className="btn-sm-ghost" onClick={() => setFormulario({ experiencia: exp })}>Editar</button>
            <button className="btn-sm-danger" onClick={() => setPorEliminar(exp)}>Eliminar</button>
          </div>
        </div>
      ))}

      {formulario && (
        <ExperienciaForm
          experiencia={formulario.experiencia}
          onSubmit={guardar}
          onCancel={() => setFormulario(null)}
          guardando={guardando}
        />
      )}

      {porEliminar && (
        <ConfirmDialog
          titulo="Eliminar experiencia"
          texto={`¿Seguro que quieres eliminar "${porEliminar.cargo}" en ${porEliminar.empresa}? Esta acción no se puede deshacer.`}
          onConfirm={eliminar}
          onCancel={() => setPorEliminar(null)}
          cargando={eliminando}
        />
      )}

      <Toast toast={toast} onClose={() => setToast(null)} />
    </main>
  );
}
