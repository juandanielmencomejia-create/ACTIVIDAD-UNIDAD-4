import Reveal from '../components/Reveal.jsx';

const TECNICAS = [
  ['Bases de datos (MySQL)', 'Intermedio', 65],
  ['HTML', 'Intermedio', 70],
  ['CSS', 'Intermedio', 65],
  ['JavaScript', 'Básico', 45],
  ['PHP', 'Básico', 45],
  ['Java', 'Básico', 40],
  ['Word', 'Intermedio', 65],
  ['Excel', 'Básico', 40],
  ['Soporte técnico', 'Intermedio', 60],
  ['Inglés', 'A2', 55],
];

const BLANDAS = [
  'Trabajo en equipo', 'Liderazgo', 'Trabajo bajo presión', 'Adaptabilidad', 'Responsabilidad',
  'Puntualidad', 'Comunicación', 'Resolución de problemas', 'Atención al cliente', 'Proactividad',
];

export default function Habilidades() {
  return (
    <main>
      <p className="eyebrow">hoja-de-vida / habilidades</p>
      <h2 style={{ marginBottom: '0.4rem' }}><span className="idx">04</span> Habilidades técnicas</h2>
      <p style={{ marginBottom: '1.5rem' }}>Conocimientos y herramientas.</p>

      <div className="skills-grid row g-3">
        {TECNICAS.map(([nombre, nivel, pct]) => (
          <div key={nombre} className="col-12 col-sm-6 col-md-4">
            <Reveal className="skill-card">
              <div className="skill-name"><span>{nombre}</span><span className="skill-level">{nivel}</span></div>
              <div className="bar"><div className="bar-fill" style={{ width: `${pct}%` }}></div></div>
            </Reveal>
          </div>
        ))}
      </div>

      <h2 style={{ marginBottom: '0.4rem' }}><span className="idx">05</span> Habilidades blandas</h2>
      <p style={{ marginBottom: '1.5rem' }}>Cómo trabajo con otras personas.</p>
      <Reveal className="chip-row">
        {BLANDAS.map((b) => <span key={b} className="chip">{b}</span>)}
      </Reveal>
    </main>
  );
}
