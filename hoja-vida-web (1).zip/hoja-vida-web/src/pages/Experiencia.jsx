import { useEffect, useState } from 'react';
import Reveal from '../components/Reveal.jsx';
import { listarExperiencias } from '../api/experiencias.js';
import { periodo } from '../utils.js';

export default function Experiencia() {
  const [items, setItems] = useState([]);
  const [estado, setEstado] = useState('cargando');
  const [error, setError] = useState('');

  useEffect(() => {
    listarExperiencias()
      .then((data) => { setItems(data); setEstado('listo'); })
      .catch((err) => { setError(err.message); setEstado('error'); });
  }, []);

  return (
    <main>
      <p className="eyebrow">hoja-de-vida / experiencia</p>
      <h2 style={{ marginBottom: '0.4rem' }}><span className="idx">03</span> Experiencia laboral</h2>
      <p style={{ marginBottom: '2rem' }}>Trabajos y labores realizadas hasta el momento.</p>

      {estado === 'cargando' && <p>Cargando experiencias…</p>}
      {estado === 'error' && <div className="api-error">{error}</div>}
      {estado === 'listo' && items.length === 0 && <p>Aún no hay experiencias registradas.</p>}

      <div className="timeline">
        {items.map((exp) => {
          const puntos = [exp.descripcion, ...(exp.logros || [])].filter(Boolean);
          const detalle = [periodo(exp), exp.ubicacion].filter(Boolean).join(' · ');
          return (
            <Reveal key={exp._id} className="card">
              <div className="card-head">
                <span className="card-title">{exp.cargo}</span>
                <span className="card-period">{exp.empresa}</span>
              </div>
              {detalle && <p className="card-sub">{detalle}</p>}
              {puntos.length > 0 && <ul>{puntos.map((p, i) => <li key={i}>{p}</li>)}</ul>}
            </Reveal>
          );
        })}
      </div>
    </main>
  );
}
