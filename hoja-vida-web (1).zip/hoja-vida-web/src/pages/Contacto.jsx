import { useState } from 'react';
import Reveal from '../components/Reveal.jsx';

const CONTACTOS = [
  { icono: '✉', etiqueta: 'Correo', valor: 'juandanielmencomejia@gmail.com', href: 'mailto:juandanielmencomejia@gmail.com' },
  { icono: '☎', etiqueta: 'Teléfono', valor: '322 668 4517', href: 'tel:+573226684517' },
  { icono: '📍', etiqueta: 'Ubicación', valor: 'Magangué Bolívar' },
  { icono: 'f', etiqueta: 'Facebook', valor: 'Menco Mejía Juan', href: 'https://www.facebook.com', externo: true },
  { icono: '♪', etiqueta: 'TikTok', valor: '@moonlight_x_x', href: 'https://www.tiktok.com/@moonlight_x_x', externo: true },
];

const CAMPOS = {
  nombre: { label: 'Nombre completo', placeholder: 'Tu nombre', error: 'Escribe tu nombre (mínimo 3 letras).', valido: (v) => v.trim().length >= 3 },
  email: { label: 'Correo electrónico', placeholder: 'tucorreo@ejemplo.com', error: 'Ingresa un correo válido.', valido: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) },
  telefono: { label: 'Teléfono (opcional)', placeholder: 'Ej: 3226684517', error: 'Ingresa solo números (7 a 10 dígitos).', valido: (v) => v.trim() === '' || /^[0-9]{7,10}$/.test(v.trim()) },
  asunto: { label: 'Asunto', placeholder: '¿Sobre qué quieres hablar?', error: 'Escribe un asunto.', valido: (v) => v.trim().length >= 3 },
  mensaje: { label: 'Mensaje', placeholder: 'Escribe tu mensaje aquí...', error: 'El mensaje debe tener al menos 10 caracteres.', valido: (v) => v.trim().length >= 10 },
};

const INICIAL = { nombre: '', email: '', telefono: '', asunto: '', mensaje: '' };

function Campo({ nombre, valor, estado, onChange, onBlur, columnas = 'col-12 col-md-6' }) {
  const c = CAMPOS[nombre];
  const clase = estado === 'invalido' ? ' is-invalid' : estado === 'valido' ? ' is-valid' : '';
  const Control = nombre === 'mensaje' ? 'textarea' : 'input';
  return (
    <div className={columnas}>
      <div className={`form-group${clase}`}>
        <label htmlFor={nombre}>{c.label}</label>
        <Control
          id={nombre}
          className="form-control"
          type={nombre === 'mensaje' ? undefined : 'text'}
          placeholder={c.placeholder}
          value={valor}
          onChange={(e) => onChange(nombre, e.target.value)}
          onBlur={() => onBlur(nombre)}
        />
        <span className="field-error">{c.error}</span>
      </div>
    </div>
  );
}

export default function Contacto() {
  const [valores, setValores] = useState(INICIAL);
  const [estados, setEstados] = useState({});
  const [enviado, setEnviado] = useState(false);

  const cambiar = (nombre, valor) => setValores((v) => ({ ...v, [nombre]: valor }));
  const validar = (nombre) => {
    const ok = CAMPOS[nombre].valido(valores[nombre]);
    setEstados((s) => ({ ...s, [nombre]: ok ? 'valido' : 'invalido' }));
    return ok;
  };

  const enviar = (e) => {
    e.preventDefault();
    const invalidos = Object.keys(CAMPOS).filter((n) => !validar(n));
    if (invalidos.length === 0) {
      setEnviado(true);
      setValores(INICIAL);
      setEstados({});
      setTimeout(() => setEnviado(false), 4000);
    } else {
      setEnviado(false);
      document.getElementById(invalidos[0])?.focus();
    }
  };

  return (
    <main>
      <p className="eyebrow">hoja-de-vida / contacto</p>
      <h2 style={{ marginBottom: '0.4rem' }}><span className="idx">06</span> Contacto</h2>
      <p style={{ marginBottom: '2rem' }}>Estas son las formas de comunicarte conmigo.</p>

      <div className="contact-grid row g-3">
        {CONTACTOS.map((c) => {
          const contenido = (
            <>
              <span className="contact-icon">{c.icono}</span>
              <span>
                <span className="contact-label">{c.etiqueta}</span><br />
                <span className="contact-value">{c.valor}</span>
              </span>
            </>
          );
          return (
            <div key={c.etiqueta} className="col-12 col-sm-6">
              <Reveal
                as={c.href ? 'a' : 'div'}
                className="contact-card"
                {...(c.href ? { href: c.href } : {})}
                {...(c.externo ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
              >
                {contenido}
              </Reveal>
            </div>
          );
        })}
      </div>

      <Reveal as="form" className="contact-form" onSubmit={enviar} noValidate>
        <h3>Escríbeme directamente</h3>
        <div className="row g-3">
          <Campo nombre="nombre" valor={valores.nombre} estado={estados.nombre} onChange={cambiar} onBlur={validar} />
          <Campo nombre="email" valor={valores.email} estado={estados.email} onChange={cambiar} onBlur={validar} />
          <Campo nombre="telefono" valor={valores.telefono} estado={estados.telefono} onChange={cambiar} onBlur={validar} />
          <Campo nombre="asunto" valor={valores.asunto} estado={estados.asunto} onChange={cambiar} onBlur={validar} />
          <Campo nombre="mensaje" valor={valores.mensaje} estado={estados.mensaje} onChange={cambiar} onBlur={validar} columnas="col-12" />
          <div className="col-12">
            <button type="submit" className="btn-submit">Enviar mensaje</button>
          </div>
        </div>
        <div className={`form-success${enviado ? ' show' : ''}`}>✔ ¡Mensaje enviado correctamente! Gracias por escribirme.</div>
      </Reveal>
    </main>
  );
}
