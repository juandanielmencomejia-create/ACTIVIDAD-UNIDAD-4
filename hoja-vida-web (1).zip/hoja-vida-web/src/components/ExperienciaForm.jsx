import { useState } from 'react';

const vacio = {
  cargo: '', empresa: '', descripcion: '', logros: '', ubicacion: '',
  fechaInicio: '', fechaFin: '', trabajoActual: false,
};

function aFormulario(exp) {
  if (!exp) return vacio;
  return {
    cargo: exp.cargo || '',
    empresa: exp.empresa || '',
    descripcion: exp.descripcion || '',
    logros: (exp.logros || []).join('\n'),
    ubicacion: exp.ubicacion || '',
    fechaInicio: exp.fechaInicio ? exp.fechaInicio.slice(0, 10) : '',
    fechaFin: exp.fechaFin ? exp.fechaFin.slice(0, 10) : '',
    trabajoActual: !!exp.trabajoActual,
  };
}

// Mismas reglas que el modelo de la API.
function validar(f) {
  const e = {};
  const cargo = f.cargo.trim();
  const empresa = f.empresa.trim();
  if (!cargo) e.cargo = 'El cargo es obligatorio';
  else if (cargo.length < 3 || cargo.length > 100) e.cargo = 'Entre 3 y 100 caracteres';
  if (!empresa) e.empresa = 'La empresa es obligatoria';
  else if (empresa.length < 2 || empresa.length > 100) e.empresa = 'Entre 2 y 100 caracteres';
  if (f.descripcion.length > 500) e.descripcion = 'Máximo 500 caracteres';
  if (f.ubicacion.length > 100) e.ubicacion = 'Máximo 100 caracteres';
  if (f.logros.split('\n').some((l) => l.trim().length > 200)) e.logros = 'Cada logro admite máximo 200 caracteres';
  if (f.fechaInicio && f.fechaFin && !f.trabajoActual && f.fechaFin < f.fechaInicio) {
    e.fechaFin = 'La fecha de fin no puede ser anterior a la de inicio';
  }
  return e;
}

export default function ExperienciaForm({ experiencia, onSubmit, onCancel, guardando }) {
  const [form, setForm] = useState(aFormulario(experiencia));
  const [errores, setErrores] = useState({});

  const cambiar = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  };

  const enviar = (e) => {
    e.preventDefault();
    const errs = validar(form);
    setErrores(errs);
    if (Object.keys(errs).length) return;

    onSubmit({
      cargo: form.cargo.trim(),
      empresa: form.empresa.trim(),
      descripcion: form.descripcion.trim(),
      logros: form.logros.split('\n').map((l) => l.trim()).filter(Boolean),
      ubicacion: form.ubicacion.trim(),
      fechaInicio: form.fechaInicio || null,
      fechaFin: form.trabajoActual ? null : form.fechaFin || null,
      trabajoActual: form.trabajoActual,
    });
  };

  const Campo = ({ id, label, children, hint }) => (
    <div className={`form-group${errores[id] ? ' is-invalid' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
      <span className="field-error">{errores[id]}</span>
    </div>
  );

  return (
    <div className="dlg-overlay" onClick={onCancel}>
      <form className="dlg" onClick={(e) => e.stopPropagation()} onSubmit={enviar} noValidate>
        <h3>{experiencia ? 'Editar experiencia' : 'Nueva experiencia'}</h3>

        <div className="grid-2">
          <Campo id="cargo" label="Cargo *">
            <input id="cargo" name="cargo" className="form-control" value={form.cargo} onChange={cambiar} />
          </Campo>
          <Campo id="empresa" label="Empresa *">
            <input id="empresa" name="empresa" className="form-control" value={form.empresa} onChange={cambiar} />
          </Campo>
        </div>

        <Campo id="ubicacion" label="Ubicación">
          <input id="ubicacion" name="ubicacion" className="form-control" value={form.ubicacion} onChange={cambiar} />
        </Campo>

        <Campo id="descripcion" label="Descripción" hint={`${form.descripcion.length}/500`}>
          <textarea id="descripcion" name="descripcion" rows="3" className="form-control" value={form.descripcion} onChange={cambiar} />
        </Campo>

        <Campo id="logros" label="Logros (uno por línea)">
          <textarea id="logros" name="logros" rows="3" className="form-control" value={form.logros} onChange={cambiar} />
        </Campo>

        <div className="grid-2">
          <Campo id="fechaInicio" label="Fecha de inicio">
            <input id="fechaInicio" type="date" name="fechaInicio" className="form-control" value={form.fechaInicio} onChange={cambiar} />
          </Campo>
          <Campo id="fechaFin" label="Fecha de fin">
            <input id="fechaFin" type="date" name="fechaFin" className="form-control" value={form.fechaFin} onChange={cambiar} disabled={form.trabajoActual} />
          </Campo>
        </div>

        <label className="check-row">
          <input type="checkbox" name="trabajoActual" checked={form.trabajoActual} onChange={cambiar} />
          Es mi trabajo actual
        </label>

        <div className="dlg-actions">
          <button type="button" className="btn-ghost" onClick={onCancel} disabled={guardando}>Cancelar</button>
          <button type="submit" className="btn-submit" disabled={guardando}>{guardando ? 'Guardando…' : 'Guardar'}</button>
        </div>
      </form>
    </div>
  );
}
