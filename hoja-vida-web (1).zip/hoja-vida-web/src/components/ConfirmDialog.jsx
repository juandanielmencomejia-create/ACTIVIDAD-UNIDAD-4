export default function ConfirmDialog({ titulo, texto, onConfirm, onCancel, cargando }) {
  return (
    <div className="dlg-overlay" onClick={onCancel}>
      <div className="dlg dlg--small" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <h3>{titulo}</h3>
        <p>{texto}</p>
        <div className="dlg-actions">
          <button className="btn-ghost" onClick={onCancel} disabled={cargando}>Cancelar</button>
          <button className="btn-danger" onClick={onConfirm} disabled={cargando}>
            {cargando ? 'Eliminando…' : 'Eliminar'}
          </button>
        </div>
      </div>
    </div>
  );
}
