import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';

const PAGINAS = [
  { path: '/', label: 'inicio', titulo: 'Juan Daniel Menco Mejía · Hoja de vida', estado: '🟢 disponible para nuevas oportunidades' },
  { path: '/formacion', label: 'formacion', titulo: 'Formación académica · Juan Daniel Menco Mejía', estado: '📚 formación académica' },
  { path: '/experiencia', label: 'experiencia', titulo: 'Experiencia laboral · Juan Daniel Menco Mejía', estado: '💼 experiencia laboral' },
  { path: '/habilidades', label: 'habilidades', titulo: 'Habilidades · Juan Daniel Menco Mejía', estado: '🛠 habilidades' },
  { path: '/contacto', label: 'contacto', titulo: 'Contacto · Juan Daniel Menco Mejía', estado: '📬 contacto' },
  { path: '/admin', label: 'admin', titulo: 'Administración · Juan Daniel Menco Mejía', estado: '⚙ panel administrativo' },
];

export default function Layout() {
  const { pathname } = useLocation();
  const [abierto, setAbierto] = useState(false);
  const pagina = PAGINAS.find((p) => p.path === pathname) || PAGINAS[0];

  useEffect(() => {
    setAbierto(false);
    document.title = pagina.titulo;
    window.scrollTo(0, 0);
  }, [pathname, pagina.titulo]);

  return (
    <>
      <nav className="tabbar-wrap">
        <div className="tabbar-inner">
          <button
            className="nav-toggle"
            aria-expanded={abierto}
            aria-controls="tabbar"
            aria-label="Abrir menú"
            onClick={() => setAbierto((v) => !v)}
          >
            ☰ menú
          </button>
          <div className={`tabbar${abierto ? ' open' : ''}`} id="tabbar">
            {PAGINAS.map((p) => (
              <NavLink key={p.path} to={p.path} end className={({ isActive }) => `tab${isActive ? ' active' : ''}`}>
                <span className="dot"></span>{p.label}
              </NavLink>
            ))}
          </div>
        </div>
      </nav>

      <Outlet />

      <footer className="statusbar">
        <span>{pagina.estado}</span>
        <span>Magangué Bolívar, Colombia</span>
      </footer>
    </>
  );
}
